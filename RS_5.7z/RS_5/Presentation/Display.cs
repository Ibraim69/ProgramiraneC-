﻿using Business;
using System;
using Data.Model;



namespace Presentation
{
    public class Display
    {
        PrintersDBBusiness printersDBBusiness = new PrintersDBBusiness();
        private int closeOperationId = 6;
        private void ShowMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 18) + "MENU" + new string(' ', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all entries");
            Console.WriteLine("2. Add new entry");
            Console.WriteLine("3. Update entry");
            Console.WriteLine("4. Fetch entry by ID");
            Console.WriteLine("5. Delete entry by ID");
            Console.WriteLine("6. Exit");
        }

        private void Input()
        {
            var operation = -1;
            do
            {
                ShowMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        ListAll();
                        break;
                    case 2:
                        Add();
                        break;
                    case 3:
                      //  Update();
                        break;
                    case 4:
                     //   Fetch();
                        break;
                    case 5:
                    //    Delete();
                        break;
                    default:
                        break;
                }
            }
            while (operation != closeOperationId);
        }
    

            
        
        public Display()
        {
            Input();
        }
        private void Add()
        {
            Printer printerdb = new Printer();
            Console.WriteLine(("Enter SerialNumber:"));
            printerdb.SerialNumber = int.Parse(Console.ReadLine());
            Console.WriteLine(("Enter PurchaseDate:"));
            printerdb.PurchaseDate = DateTime.Parse(Console.ReadLine());
            Console.WriteLine(("Enter WarrantyExpiryPeriod:"));
            printerdb.WarrantyExpiryPeriod = int.Parse(Console.ReadLine());
            printersDBBusiness.AddPrinter(printerdb);
        }
        private void ListAll()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 16) + "PRODUCTS" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            var printer = printersDBBusiness.GetAll();
            foreach (var item in printer)
            {
                Console.WriteLine("{0} {1} {2} {3}", item.Id, item.Name, item.Price, item.Stock);
            }
        }
        private void Update()
        {
            Console.WriteLine("Enter ID to update: ");
            int id = int.Parse(Console.ReadLine());
            PrintersDBBusiness printersDBBusiness = printersDBBusiness.GetPrinter(id);
            if (printersDBBusiness != null)
            {
                Printer printerdb = new Printer();
                Console.WriteLine(("Enter SerialNumber:"));
                printerdb.SerialNumber = int.Parse(Console.ReadLine());
                Console.WriteLine(("Enter PurchaseDate:"));
                printerdb.PurchaseDate = DateTime.Parse(Console.ReadLine());
                Console.WriteLine(("Enter WarrantyExpiryPeriod:"));
                printerdb.WarrantyExpiryPeriod = int.Parse(Console.ReadLine());
                product.Business.Add(product);
            }
        }
        private void Fetch()
        {
            Console.WriteLine("Enter ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            Product product = productBusiness.Get(id);
            if (product != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("ID: " + product.Id);
                Console.WriteLine("Name: " + product.Id);
                Console.WriteLine("Price: " + product.Id);
                Console.WriteLine("Stock: " + product.Id);
                Console.WriteLine(new string('-', 40));
            }
        }
        private void Delete()
        {
            Console.WriteLine("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            productBusiness.Delete(id);
            Console.WriteLine("Done.");
        }
    }
    }

