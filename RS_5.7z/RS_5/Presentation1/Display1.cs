﻿using Business;
using Data.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentation1
{
    public class Display1
    {
        PrintersDBBusiness printersDBBusiness = new PrintersDBBusiness();
        private int closeOperationId = 6;
        private void ShowMenu()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 18) + "MENU" + new string(' ', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all entries");
            Console.WriteLine("2. Add new entry");
            Console.WriteLine("3. Update entry");
            Console.WriteLine("4. Fetch entry by ID");
            Console.WriteLine("5. Delete entry by ID");
            Console.WriteLine("6. Exit");
        }

        private void Input()
        {
            var operation = -1;
            do
            {
                ShowMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        ListAll();
                        break;
                    case 2:
                        Add();
                        break;
                    case 3:
                          Update();
                        break;
                    case 4:
                          Fetch();
                        break;
                    case 5:
                            Delete();
                        break;
                    default:
                        break;
                }
            }
            while (operation != closeOperationId);
        }




        public Display1()
        {
            Input();
            Input1();
        }
        private void Add()
        {
            Printer printerdb = new Printer();
            Console.WriteLine(("Enter SerialNumber:"));
            printerdb.SerialNumber = int.Parse(Console.ReadLine());
            Console.WriteLine(("Enter PurchaseDate:"));
            printerdb.PurchaseDate = DateTime.Parse(Console.ReadLine());
            Console.WriteLine(("Enter WarrantyExpiryPeriod:"));
            printerdb.WarrantyExpiryPeriod = int.Parse(Console.ReadLine());
            printersDBBusiness.AddPrinter(printerdb);
        }
        private void ListAll()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 16) + "PRINTER" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            var printer = printersDBBusiness.GetAllPrinter();
            foreach (var item in printer)
            {
                Console.WriteLine("{0} {1} {2} {3}", item.Id, item.SerialNumber, item.PurchaseDate, item.WarrantyExpiryPeriod);
            }
        }
        private void Update()
        {
            Console.WriteLine("Enter ID to update: ");
            int id = int.Parse(Console.ReadLine());
            Printer printer = printersDBBusiness.GetPrinter(id);
            if (printersDBBusiness != null)
            {            
                Console.WriteLine(("Enter SerialNumber:"));
                printer.SerialNumber = int.Parse(Console.ReadLine());
                Console.WriteLine(("Enter PurchaseDate:"));
                printer.PurchaseDate = DateTime.Parse(Console.ReadLine());
                Console.WriteLine(("Enter WarrantyExpiryPeriod:"));
                printer.WarrantyExpiryPeriod = int.Parse(Console.ReadLine());
                printersDBBusiness.UpdatePrinter(printer);
            }
        }
        private void Fetch()
        {
            Console.WriteLine("Enter ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            Printer printer = printersDBBusiness.GetPrinter(id);
            if (printer != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("ID: " + printer.Id);
                Console.WriteLine("SerialNumber: " + printer.SerialNumber);
                Console.WriteLine("PurchaseDate: " + printer.PurchaseDate);
                Console.WriteLine("WarrantyExpiryPeriod: " + printer.WarrantyExpiryPeriod);
                Console.WriteLine(new string('-', 40));
            }
        }
        private void Delete()
        {
            Console.WriteLine("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            printersDBBusiness.DeletePrinter(id);
            Console.WriteLine("Done.");
        }
        //PrinterModel
        private void ShowMenuM()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 18) + "MENU" + new string(' ', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. List all entries");
            Console.WriteLine("2. Add new entry");
            Console.WriteLine("3. Update entry");
            Console.WriteLine("4. Fetch entry by ID");
            Console.WriteLine("5. Delete entry by ID");
            Console.WriteLine("6. Exit");
        }

        private void Input1()
        {
            var operation = -1;
            do
            {
                ShowMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        ListAllModel();
                        break;
                    case 2:
                        AddModel();
                        break;
                    case 3:
                        UpdateModel();
                        break;
                    case 4:
                        FetchM();
                        break;
                    case 5:
                       DeleteModel();
                        break;
                    default:
                        break;
                }
            }
            while (operation != closeOperationId);
        }





        private void AddModel()
        {
            PrinterModel printermodel = new PrinterModel();
            Console.WriteLine(("Enter ModelName:"));
            printermodel.ModelName = (Console.ReadLine());
            Console.WriteLine(("Enter Type:"));
            printermodel.Type = (Console.ReadLine());
            Console.WriteLine(("Enter Resolution:"));
            printermodel.Resolution = int.Parse(Console.ReadLine());
            Console.WriteLine(("Enter PrintSpeed"));
            printermodel.PrintSpeed = float.Parse(Console.ReadLine());
            printersDBBusiness.AddModel(printermodel);
        }
        private void ListAllModel()
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string('-', 16) + "PRINTERMODEL" + new string(' ', 16));
            Console.WriteLine(new string('-', 40));
            var printermodel1 = printersDBBusiness.GetAllModel();
            foreach (var item in printermodel1)
            {
                Console.WriteLine("{0} {1} {2} {3} {4}", item.Id, item.ModelName, item.Type, item.Resolution, item.PrintSpeed);
            }
        }
        private void UpdateModel()
        {
            Console.WriteLine("Enter ID to update: ");
            int id = int.Parse(Console.ReadLine());
            PrinterModel pi = printersDBBusiness.GetModel(id);
            if (printersDBBusiness != null)
            {
                PrinterModel printermodel = new PrinterModel();
                Console.WriteLine(("Enter ModelName:"));
                printermodel.ModelName = (Console.ReadLine());
                Console.WriteLine(("Enter Type:"));
                printermodel.Type = (Console.ReadLine());
                Console.WriteLine(("Enter Resolution:"));
                printermodel.Resolution = int.Parse(Console.ReadLine());
                Console.WriteLine(("Enter PrintSpeed"));
                printermodel.PrintSpeed = float.Parse(Console.ReadLine());           
                printersDBBusiness.UpdateModel(pi);
            }
        }
        private void FetchM()
        {
            Console.WriteLine("Enter ID to fetch: ");
            int id = int.Parse(Console.ReadLine());
            PrinterModel pri = printersDBBusiness.GetModel(id);
            if (pri != null)
            {
                Console.WriteLine(new string('-', 40));
                Console.WriteLine("ID: " + pri.Id);
                Console.WriteLine("SerialNumber: " + pri.ModelName);
                Console.WriteLine("PurchaseDate: " + pri.Type);
                Console.WriteLine("WarrantyExpiryPeriod: " + pri.Resolution);
                Console.WriteLine("PrintSpeed:" + pri.PrintSpeed);
                Console.WriteLine(new string('-', 40));
            }
        }
        private void DeleteModel()
        {
            Console.WriteLine("Enter ID to delete: ");
            int id = int.Parse(Console.ReadLine());
            printersDBBusiness.DeletePrinterModel(id);
            Console.WriteLine("Done.");
        }
        ////Cartridge
        //private void ShowMenuC()
        //{
        //    Console.WriteLine(new string('-', 40));
        //    Console.WriteLine(new string('-', 18) + "MENU" + new string(' ', 18));
        //    Console.WriteLine(new string('-', 40));
        //    Console.WriteLine("1. List all entries");
        //    Console.WriteLine("2. Add new entry");
        //    Console.WriteLine("3. Update entry");
        //    Console.WriteLine("4. Fetch entry by ID");
        //    Console.WriteLine("5. Delete entry by ID");
        //    Console.WriteLine("6. Exit");
        //}

        //        private void Input2()
        //        {
        //            var operation = -1;
        //            do
        //            {
        //                ShowMenu();
        //                operation = int.Parse(Console.ReadLine());
        //                switch (operation)
        //                {
        //                    case 1:
        //                        ListAllCartridge();
        //                        break;
        //                    case 2:
        //                        AddCartridge();
        //                        break;
        //                    case 3:
        //                        UpdateCartridge();
        //                        break;
        //                    case 4:
        //                        FetchC();
        //                        break;
        //                    case 5:
        //                       DeleteC();
        //                        break;
        //                    default:
        //                        break;
        //                }
        //            }
        //            while (operation != closeOperationId);
        //        }




        //        private void AddCartridge()
        //        {
        //            Cartridge cartridge = new Cartridge();
        //            Console.WriteLine(("Enter RemainingPages:"));
        //            cartridge.RemainingPages =(Console.ReadLine());
        //        }
        //        private void ListAllCartridge()
        //        {
        //            Console.WriteLine(new string('-', 40));
        //            Console.WriteLine(new string('-', 16) + "CARTRIDGE" + new string(' ', 16));
        //            Console.WriteLine(new string('-', 40));
        //            var cartridge1 = printersDBBusiness.GetAllModel();
        //            foreach (var item in cartridge1)
        //            {
        //                Console.WriteLine("{0} {1} }", item.Id, item.RemainingPages);
        //            }
        //        }
        //        private void UpdateModel()
        //        {
        //            Console.WriteLine("Enter ID to update: ");
        //            int id = int.Parse(Console.ReadLine());
        //            PrinterModel pi = printersDBBusiness.GetModel(id);
        //            if (printersDBBusiness != null)
        //            {
        //                PrinterModel printermodel = new PrinterModel();
        //                Console.WriteLine(("Enter ModelName:"));
        //                printermodel.ModelName = (Console.ReadLine());
        //                Console.WriteLine(("Enter Type:"));
        //                printermodel.Type = (Console.ReadLine());
        //                Console.WriteLine(("Enter Resolution:"));
        //                printermodel.Resolution = int.Parse(Console.ReadLine());
        //                Console.WriteLine(("Enter PrintSpeed"));
        //                printermodel.PrintSpeed = float.Parse(Console.ReadLine());
        //                printersDBBusiness.UpdateModel(pi);
        //            }
        //        }
        //        private void FetchM()
        //        {
        //            Console.WriteLine("Enter ID to fetch: ");
        //            int id = int.Parse(Console.ReadLine());
        //            PrinterModel pri = printersDBBusiness.GetModel(id);
        //            if (pri != null)
        //            {
        //                Console.WriteLine(new string('-', 40));
        //                Console.WriteLine("ID: " + pri.Id);
        //                Console.WriteLine("SerialNumber: " + pri.ModelName);
        //                Console.WriteLine("PurchaseDate: " + pri.Type);
        //                Console.WriteLine("WarrantyExpiryPeriod: " + pri.Resolution);
        //                Console.WriteLine("PrintSpeed:" + pri.PrintSpeed);
        //                Console.WriteLine(new string('-', 40));
        //            }
        //        }
        //        private void DeleteModel()
        //        {
        //            Console.WriteLine("Enter ID to delete: ");
        //            int id = int.Parse(Console.ReadLine());
        //            printersDBBusiness.DeleteModel(id);
        //            Console.WriteLine("Done.");
        //        }
    }
}


