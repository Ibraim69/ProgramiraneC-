﻿using System;

namespace Presentation1
{
    class Program
    {
        static void Main(string[] args)
        {
            Display1 display = new Display1();
        }
    }
}
