﻿using Data;
using System;

namespace RS_5
{
    class Program
    {
        static void Main(string[] args)
        {
            PrintersDBContext printersDBContext = new PrintersDBContext();
        }
    }
}
