﻿using System;
using System.Collections.Generic;
using Data;
using System.Linq;
using Data.Model;

namespace Business
{
    public class PrintersDBBusiness
    {

        private PrintersDBContext printersDBContext;
        public List<Printer> GetAllPrinter()
        {
            using (printersDBContext = new PrintersDBContext())
            {
                return printersDBContext.Printers.ToList();
            }
        }
        public Printer GetPrinter(int id)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                return printersDBContext.Printers.Find(id);
            }
        }
        public void AddPrinter(Printer printer)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                printersDBContext.Printers.Add(printer);
                printersDBContext.SaveChanges();
            }
        }
        public void UpdatePrinter(Printer product)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                var item = printersDBContext.Printers.Find(product.Id);
                if (item != null)
                {
                    printersDBContext.Entry(item).CurrentValues.SetValues(product);
                    printersDBContext.SaveChanges();
                }
            }
        }
        public void DeletePrinter(int id)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                var product = printersDBContext.Printers.Find(id);
                if (product != null)
                {
                    printersDBContext.Printers.Remove(product);
                    printersDBContext.SaveChanges();
                }
            }
        }
        //PrinterModel
        public List<PrinterModel> GetAllModel()
        {
            using (printersDBContext = new PrintersDBContext())
            {
                return printersDBContext.PrinterModels.ToList();
            }
        }
        public PrinterModel GetModel(int id)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                return printersDBContext.PrinterModels.Find(id);
            }
        }
        public void AddModel(PrinterModel printerModel)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                printersDBContext.PrinterModels.Add(printerModel);
                printersDBContext.SaveChanges();
            }
        }
        public void UpdateModel(PrinterModel printerModel)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                var item = printersDBContext.PrinterModels.Find(printerModel.Id);
                if (item != null)
                {
                    printersDBContext.Entry(item).CurrentValues.SetValues(printerModel);
                    printersDBContext.SaveChanges();
                }
            }
        }
        public void DeletePrinterModel(int id)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                var printerModel = printersDBContext.PrinterModels.Find(id);
                if (printerModel != null)
                {
                    printersDBContext.PrinterModels.Remove(printerModel);
                    printersDBContext.SaveChanges();
                }

            }
        }
        //Cartridge
        public List<PrinterModel> GetAllCartridge()
        {
            using (printersDBContext = new PrintersDBContext())
            {
                return printersDBContext.PrinterModels.ToList();
            }
        }
        public Cartridge GetCartridge(int id)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                return printersDBContext.Cartridges.Find(id);
            }
        }
        public void AddCartridge(Cartridge c)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                printersDBContext.Cartridges.Add(c);
                printersDBContext.SaveChanges();
            }
        }
        public void UpdateCartridge(Cartridge product)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                var item = printersDBContext.Printers.Find(product.Id);
                if (item != null)
                {
                    printersDBContext.Entry(item).CurrentValues.SetValues(product);
                    printersDBContext.SaveChanges();
                }
            }
        }
        public void DeleteCartridge(int id)
        {
            using (printersDBContext = new PrintersDBContext())
            {
                var product = printersDBContext.Printers.Find(id);
                if (product != null)
                {
                    printersDBContext.Printers.Remove(product);
                    printersDBContext.SaveChanges();
                }
            }
        }
    }
}