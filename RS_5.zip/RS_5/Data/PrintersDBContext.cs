﻿using Data.Model;
using Microsoft.EntityFrameworkCore;
using System;

namespace Data
{
    public class PrintersDBContext : DbContext
    {
        public PrintersDBContext()
        {
            Database.EnsureCreated();
        }
       protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Data Source=(localdb)\MSSQLLocalDB; Initial Catalog = PrintersDB;");
        }
        public DbSet<Printer>Printers { get; set; }
        public DbSet<PrinterModel> PrinterModels { get; set; }
        public DbSet<CartridgesModel> CartridgesModels { get; set; }
        public DbSet<Cartridge> Cartridges { get; set; }
    }
}
