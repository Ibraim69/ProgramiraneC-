﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Model
{
   public class Cartridge
    {
        public int Id { get; set; }
        [Required]
        public int RemainingPages { get; set; }
        // public CartridgeModel string {get; set;}
    }
}
