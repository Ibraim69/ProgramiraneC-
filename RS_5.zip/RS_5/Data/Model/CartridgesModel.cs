﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Model
{
    public class CartridgesModel
    {
        public int Id { get; set; }
        [StringLength(50)]
        public string CartidgeModel { get; set; }
        [Required]
        public bool Color_BW { get; set; }
        [Required]
        public int PageYield { get; set; }
        [Required]
        public decimal Price { get; set; }
    }
}
