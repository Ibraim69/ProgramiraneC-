﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Model
{
    public class PrinterModel
    {
        public int Id { get; set; }
        [StringLength(50)]
        public string ModelName { get; set; }
        [StringLength(50)]
        public string Type { get; set; }
        [Required]
        public int Resolution { get; set; }
        [Required]
        public float PrintSpeed { get; set; }
    }
}
