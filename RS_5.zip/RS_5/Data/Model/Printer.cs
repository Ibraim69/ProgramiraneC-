﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data.Model
{
  public  class Printer
    {
        public int Id { get; set; }
        [Required]
        public int SerialNumber { get; set; }
        public DateTime? PurchaseDate { get; set; }
        [Required]
        public int WarrantyExpiryPeriod { get; set; }
        //  public int Model { get; set; }
    }
}
